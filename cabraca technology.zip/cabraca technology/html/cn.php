<?php
$conexion = mysqli_connect("localhost","root","cabraca061099","technology");
//if (!$conexion) {
 //   echo'error al conectar a la base de datos';
//} 
//else{
  //  echo'conectado a la base de datos';
//}

?>